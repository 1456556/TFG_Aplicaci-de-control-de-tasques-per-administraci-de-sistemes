/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Victor
 */
public class Perfil {

    String contrasenya1;
    String contrasenya2;

    public String getContrasenya2() {
        return contrasenya2;
    }

    public void setContrasenya2(String contrasenya2) {
        this.contrasenya2 = contrasenya2;
    }

    public String getContrasenya1() {
        return contrasenya1;
    }

    public void setContrasenya1(String contrasenya1) {
        this.contrasenya1 = contrasenya1;
    }

}
